// CSS
void sendCSS();

// script
void sendJavascript();

// NTP settings
void send_NTP_configuration_html();
void send_NTP_configuration_values_html();

// Network config
void send_network_configuration_html();
void send_network_configuration_values_html();
void send_connection_state_values_html();

// Information
void send_information_values_html();
void sendInformationPage();

// General device name only for now
void send_devicename_value_html();
void send_general_html();
void send_general_configuration_values_html();

// Admin index menu
void showAdminMainPage();








